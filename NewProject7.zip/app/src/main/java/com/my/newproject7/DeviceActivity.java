package com.my.newproject7;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ListView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.android.material.appbar.AppBarLayout;
import com.my.newproject7.databinding.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class DeviceActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private DeviceBinding binding;
	
	private ArrayList<HashMap<String, Object>> listmap = new ArrayList<>();
	
	private TimerTask timer;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		binding = DeviceBinding.inflate(getLayoutInflater());
		setContentView(binding.getRoot());
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		setSupportActionBar(binding.Toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		binding.Toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
	}
	
	private void initializeLogic() {
		HashMap<String, Object> _item;
		android.hardware.camera2.CameraManager manager = (android.hardware.camera2.CameraManager) getSystemService(android.content.Context.CAMERA_SERVICE);
		
		try {
			String[] cameraIds = manager.getCameraIdList();
			for (String cameraId : cameraIds) {
				android.hardware.camera2.CameraCharacteristics chars = manager.getCameraCharacteristics(cameraId);
				Integer facing = chars.get(android.hardware.camera2.CameraCharacteristics.LENS_FACING);
				
				String camTitle = "Camera";
				if (facing != null) {
					if (facing == android.hardware.camera2.CameraCharacteristics.LENS_FACING_BACK) camTitle = "Rear-Facing Camera";
					else if (facing == android.hardware.camera2.CameraCharacteristics.LENS_FACING_FRONT) camTitle = "Front-Facing Camera";
					else if (facing == android.hardware.camera2.CameraCharacteristics.LENS_FACING_EXTERNAL) camTitle = "External Camera";
				}
				
				// হেডার
				_item = new HashMap<>(); _item.put("title", "\n" + camTitle); _item.put("info", ""); listmap.add(_item);
				
				// ১. Resolution
				android.hardware.camera2.params.StreamConfigurationMap map = chars.get(android.hardware.camera2.CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
				if (map != null) {
					android.util.Size[] sizes = map.getOutputSizes(android.graphics.ImageFormat.JPEG);
					if (sizes != null && sizes.length > 0) {
						android.util.Size max = sizes[0];
						for (android.util.Size s : sizes) {
							if (s.getWidth() * s.getHeight() > max.getWidth() * max.getHeight()) max = s;
						}
						float mp = (max.getWidth() * max.getHeight()) / 1000000.0f;
						_item = new HashMap<>(); _item.put("title", "Resolution"); _item.put("info", String.format("%.0f MP (%d x %d)", mp, max.getWidth(), max.getHeight())); listmap.add(_item);
					}
				}
				
				// ২. Focal Length
				float[] focalLengths = chars.get(android.hardware.camera2.CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS);
				if (focalLengths != null && focalLengths.length > 0) {
					_item = new HashMap<>(); _item.put("title", "Focal Length"); _item.put("info", String.format("%.2f mm", focalLengths[0])); listmap.add(_item);
				}
				
				// ৩. Focus Modes
				int[] afModes = chars.get(android.hardware.camera2.CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES);
				if (afModes != null) {
					java.util.ArrayList<String> modesList = new java.util.ArrayList<>();
					for (int mode : afModes) {
						if(mode == 0) modesList.add("off");
						else if(mode == 1) modesList.add("auto");
						else if(mode == 2) modesList.add("macro");
						else if(mode == 3) modesList.add("continuous-video");
						else if(mode == 4) modesList.add("continuous-picture");
						else if(mode == 5) modesList.add("edof");
					}
					if(!modesList.isEmpty()) {
						_item = new HashMap<>(); _item.put("title", "Focus Modes"); _item.put("info", android.text.TextUtils.join(", ", modesList)); listmap.add(_item);
					}
				}
				
				// ৪. Video Stabilization
				int[] vStab = chars.get(android.hardware.camera2.CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES);
				boolean hasVStab = false;
				if(vStab != null) {
					for(int v : vStab) if(v != 0) { hasVStab = true; break; }
				}
				_item = new HashMap<>(); _item.put("title", "Video Stabilization"); _item.put("info", hasVStab ? "Supported" : "Not Supported"); listmap.add(_item);
				
				// ৫. Zoom
				Float maxZoom = chars.get(android.hardware.camera2.CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM);
				_item = new HashMap<>(); _item.put("title", "Zoom"); _item.put("info", (maxZoom != null && maxZoom > 1.0f) ? "Supported" : "Not Supported"); listmap.add(_item);
				
				// ৬. AE Lock & AWB Lock
				Boolean aeLock = chars.get(android.hardware.camera2.CameraCharacteristics.CONTROL_AE_LOCK_AVAILABLE);
				_item = new HashMap<>(); _item.put("title", "Auto Exposure Locking"); _item.put("info", (aeLock != null && aeLock) ? "Supported" : "Not Supported"); listmap.add(_item);
				
				Boolean awbLock = chars.get(android.hardware.camera2.CameraCharacteristics.CONTROL_AWB_LOCK_AVAILABLE);
				_item = new HashMap<>(); _item.put("title", "Auto White Balance Locking"); _item.put("info", (awbLock != null && awbLock) ? "Supported" : "Not Supported"); listmap.add(_item);
				
				// ৭. Flash
				Boolean flash = chars.get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE);
				_item = new HashMap<>(); _item.put("title", "Flash"); _item.put("info", (flash != null && flash) ? "Supported" : "Not Supported"); listmap.add(_item);
			}
			
			// ==========================================
			//           FINGERPRINT SCANNER
			// ==========================================
			android.hardware.fingerprint.FingerprintManager fpm = (android.hardware.fingerprint.FingerprintManager) getSystemService(android.content.Context.FINGERPRINT_SERVICE);
			if (fpm != null && fpm.isHardwareDetected()) {
				_item = new HashMap<>(); _item.put("title", "\nFingerprint Scanner"); _item.put("info", ""); listmap.add(_item);
				_item = new HashMap<>(); _item.put("title", "Manufacturer"); _item.put("info", android.os.Build.MANUFACTURER.toUpperCase()); listmap.add(_item);
				_item = new HashMap<>(); _item.put("title", "Model"); _item.put("info", "Hardware Detected"); listmap.add(_item);
			}
			
			// ==========================================
			//              VULKAN DEVICE
			// ==========================================
			_item = new HashMap<>(); _item.put("title", "\nVulkan Device"); _item.put("info", ""); listmap.add(_item);
			
			String vulkanVer = "Not Supported";
			android.content.pm.FeatureInfo[] features = getPackageManager().getSystemAvailableFeatures();
			if (features != null) {
				for (android.content.pm.FeatureInfo f : features) {
					if (android.content.pm.PackageManager.FEATURE_VULKAN_HARDWARE_VERSION.equals(f.name)) {
						int v = f.version;
						vulkanVer = (v >> 22) + "." + ((v >> 12) & 0x3FF) + "." + (v & 0xFFF);
						break;
					}
				}
			}
			_item = new HashMap<>(); _item.put("title", "Vulkan Hardware Version"); _item.put("info", vulkanVer); listmap.add(_item);
			_item = new HashMap<>(); _item.put("title", "Note"); _item.put("info", "Advanced Vulkan limits require C++ NDK"); listmap.add(_item);
			
		} catch (Exception e) {}
		
		
		
		
		// ==========================================
		//       USB, OpenCL, CUDA, PCI DEVICES
		// ==========================================
		
		// USB Device চেকিং
		android.hardware.usb.UsbManager usbManager = (android.hardware.usb.UsbManager) getSystemService(android.content.Context.USB_SERVICE);
		if (usbManager != null && !usbManager.getDeviceList().isEmpty()) {
			_item = new HashMap<>(); 
			_item.put("title", usbManager.getDeviceList().size() + " USB device(s) found."); 
			_item.put("info", " "); // স্পেস দেওয়া হলো যাতে ডিজাইন ঠিক থাকে
			listmap.add(_item);
		} else {
			_item = new HashMap<>(); 
			_item.put("title", "No USB devices found."); 
			_item.put("info", " "); 
			listmap.add(_item);
		}
		
		// OpenCL, CUDA, PCI (এগুলো সাধারণত অ্যান্ড্রয়েডে থাকে না, তাই AIDA64-এর মতো হার্ডকোড চেকিং)
		_item = new HashMap<>(); _item.put("title", "No OpenCL devices found."); _item.put("info", " "); listmap.add(_item);
		_item = new HashMap<>(); _item.put("title", "No CUDA devices found."); _item.put("info", " "); listmap.add(_item);
		_item = new HashMap<>(); _item.put("title", "No PCI devices found."); _item.put("info", " "); listmap.add(_item);
		binding.listview1.setAdapter(new Listview1Adapter(listmap));
		timer = new TimerTask() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						android.app.ActivityManager actManager = (android.app.ActivityManager) getSystemService(android.content.Context.ACTIVITY_SERVICE);
						android.app.ActivityManager.MemoryInfo memInfo = new android.app.ActivityManager.MemoryInfo();
						actManager.getMemoryInfo(memInfo);
						
						long totalRam = memInfo.totalMem / (1024 * 1024);
						long availRam = memInfo.availMem / (1024 * 1024);
						
						// পজিশন ৮ এবং ৯-এ RAM-এর ডাটা আছে, সেটা লাইভ আপডেট করা হচ্ছে
						if(listmap.size() > 9) {
							listmap.get(8).put("info", totalRam + " MB");
							listmap.get(9).put("info", availRam + " MB");
						}
						((BaseAdapter)binding.listview1.getAdapter()).notifyDataSetChanged();
					}
				});
			}
		};
		_timer.scheduleAtFixedRate(timer, (int)(0), (int)(1000));
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			InfoRowBinding binding = InfoRowBinding.inflate(getLayoutInflater());
			View _view = binding.getRoot();
			
			binding.textview1.setText(listmap.get((int)_position).get("title").toString());
			binding.textview2.setText(listmap.get((int)_position).get("info").toString());
			if (listmap.get((int)_position).get("info").toString().equals("")) {
				binding.textview2.setVisibility(View.GONE);
				binding.textview1.setGravity(Gravity.CENTER_VERTICAL | Gravity.CENTER_HORIZONTAL);
				binding.textview1.setTypeface(Typeface.DEFAULT, 1);
			} else {
				binding.textview2.setVisibility(View.VISIBLE);
				binding.textview1.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
				binding.textview1.setTypeface(Typeface.DEFAULT, 0);
			}
			
			return _view;
		}
	}
}