package com.my.newproject7;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ListView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.android.material.appbar.AppBarLayout;
import com.my.newproject7.databinding.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class SystemfilesActivity extends AppCompatActivity {
	
	private SystemfilesBinding binding;
	
	private ArrayList<HashMap<String, Object>> sysfile_map = new ArrayList<>();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		binding = SystemfilesBinding.inflate(getLayoutInflater());
		setContentView(binding.getRoot());
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		setSupportActionBar(binding.Toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		binding.Toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
	}
	
	private void initializeLogic() {
		sysfile_map.clear();
		java.util.LinkedHashMap<String, String> sysFiles = new java.util.LinkedHashMap<>();
		
		// আপনার ছবি অনুযায়ী ফাইলগুলোর নাম এবং পাথ
		sysFiles.put("Buddy Info", "/proc/buddyinfo");
		sysFiles.put("Build Properties", "/system/build.prop");
		sysFiles.put("Character & Block Devices", "/proc/devices");
		sysFiles.put("Command Line", "/proc/cmdline");
		sysFiles.put("CPU Information", "/proc/cpuinfo");
		sysFiles.put("Execution Domains", "/proc/execdomains");
		sysFiles.put("File Systems", "/proc/filesystems");
		sysFiles.put("Hosts", "/system/etc/hosts");
		sysFiles.put("Interrupts", "/proc/interrupts");
		sysFiles.put("Input Devices", "/proc/bus/input/devices");
		sysFiles.put("I/O Ports", "/proc/ioports");
		sysFiles.put("Kernel Version", "/proc/version");
		sysFiles.put("Load Average", "/proc/loadavg");
		sysFiles.put("Locked Files", "/proc/locks");
		sysFiles.put("Memory Information", "/proc/meminfo");
		sysFiles.put("Memory Map", "/proc/iomem");
		sysFiles.put("Misc Drivers", "/proc/misc");
		sysFiles.put("Partitions", "/proc/partitions");
		sysFiles.put("PCI Devices", "/proc/bus/pci/devices");
		sysFiles.put("Slab Info", "/proc/slabinfo");
		sysFiles.put("Statistics", "/proc/stat");
		sysFiles.put("Swap Spaces", "/proc/swaps");
		
		// ম্যাপের ভেতরে ডাটা পাঠানো
		for (java.util.Map.Entry<String, String> entry : sysFiles.entrySet()) {
			java.util.HashMap<String, Object> _item = new java.util.HashMap<>();
			_item.put("title", entry.getKey());
			_item.put("value", entry.getValue());
			sysfile_map.add(_item);
		}
		
		binding.listview1.setAdapter(new Listview1Adapter(sysfile_map));
		((BaseAdapter)binding.listview1.getAdapter()).notifyDataSetChanged();
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			InfoRowBinding binding = InfoRowBinding.inflate(getLayoutInflater());
			View _view = binding.getRoot();
			
			binding.textview1.setText(sysfile_map.get((int)_position).get("title").toString());
			binding.textview2.setText(sysfile_map.get((int)_position).get("value").toString());
			
			return _view;
		}
	}
}