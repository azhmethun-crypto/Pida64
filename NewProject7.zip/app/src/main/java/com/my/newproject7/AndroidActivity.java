package com.my.newproject7;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ListView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.android.material.appbar.AppBarLayout;
import com.my.newproject7.databinding.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class AndroidActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private AndroidBinding binding;
	
	private ArrayList<HashMap<String, Object>> listmap = new ArrayList<>();
	
	private TimerTask timer;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		binding = AndroidBinding.inflate(getLayoutInflater());
		setContentView(binding.getRoot());
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		setSupportActionBar(binding.Toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		binding.Toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
	}
	
	private void initializeLogic() {
		HashMap<String, Object> _item;
		
		// 1. Android Version
		String version = android.os.Build.VERSION.RELEASE;
		String codeName = "Unknown";
		int sdk = android.os.Build.VERSION.SDK_INT;
		if(sdk == 36) codeName = "Baklava";
		else if(sdk == 35) codeName = "Vanilla Ice Cream";
		else if(sdk == 34) codeName = "Upside Down Cake";
		else if(sdk == 33) codeName = "Tiramisu";
		else if(sdk == 32 || sdk == 31) codeName = "Snow Cone";
		else if(sdk == 30) codeName = "Red Velvet Cake";
		else if(sdk == 29) codeName = "Quince Tart";
		else if(sdk == 28) codeName = "Pie";
		else if(sdk == 27 || sdk == 26) codeName = "Oreo";
		_item = new HashMap<>(); _item.put("title", "Android Version"); _item.put("info", version + " (" + codeName + ")"); listmap.add(_item);
		
		// 2. API Level
		_item = new HashMap<>(); _item.put("title", "API Level"); _item.put("info", String.valueOf(sdk)); listmap.add(_item);
		
		// 3. Security Patch
		String patch = "Unknown";
		if (android.os.Build.VERSION.SDK_INT >= 23) {
			patch = android.os.Build.VERSION.SECURITY_PATCH;
		}
		_item = new HashMap<>(); _item.put("title", "Android Security Patch Level"); _item.put("info", patch); listmap.add(_item);
		
		// 4. Rooted Device
		boolean isRooted = new java.io.File("/system/xbin/su").exists() || new java.io.File("/system/bin/su").exists();
		_item = new HashMap<>(); _item.put("title", "Rooted Device"); _item.put("info", isRooted ? "Yes" : "No"); listmap.add(_item);
		
		// 5. Android ID
		String androidId = android.provider.Settings.Secure.getString(getContentResolver(), android.provider.Settings.Secure.ANDROID_ID);
		_item = new HashMap<>(); _item.put("title", "Android ID"); _item.put("info", androidId != null ? androidId : "Unknown"); listmap.add(_item);
		
		// 6. Baseband
		String baseband = "Unknown";
		try { baseband = android.os.Build.getRadioVersion(); } catch(Exception e){}
		_item = new HashMap<>(); _item.put("title", "Baseband"); _item.put("info", baseband != null ? baseband : "Unknown"); listmap.add(_item);
		
		// 7. Bootloader
		_item = new HashMap<>(); _item.put("title", "Bootloader"); _item.put("info", android.os.Build.BOOTLOADER); listmap.add(_item);
		
		// 8. Build ID & Codename
		_item = new HashMap<>(); _item.put("title", "Build ID"); _item.put("info", android.os.Build.DISPLAY); listmap.add(_item);
		_item = new HashMap<>(); _item.put("title", "Codename"); _item.put("info", android.os.Build.VERSION.CODENAME); listmap.add(_item);
		
		// 9. Fingerprint & ID
		_item = new HashMap<>(); _item.put("title", "Fingerprint"); _item.put("info", android.os.Build.FINGERPRINT); listmap.add(_item);
		_item = new HashMap<>(); _item.put("title", "ID"); _item.put("info", android.os.Build.ID); listmap.add(_item);
		_item = new HashMap<>(); _item.put("title", "Incremental"); _item.put("info", android.os.Build.VERSION.INCREMENTAL); listmap.add(_item);
		
		// 10. Java & VM Info
		_item = new HashMap<>(); _item.put("title", "Java Runtime Version"); _item.put("info", System.getProperty("java.runtime.name", "Android Runtime") + " " + System.getProperty("java.runtime.version", "0.9")); listmap.add(_item);
		_item = new HashMap<>(); _item.put("title", "Java VM Version"); _item.put("info", System.getProperty("java.vm.name", "ART") + " " + System.getProperty("java.vm.version", "2.1.0")); listmap.add(_item);
		
		long heapSize = Runtime.getRuntime().maxMemory() / (1024 * 1024);
		_item = new HashMap<>(); _item.put("title", "Java VM Heap Size"); _item.put("info", heapSize + " MB"); listmap.add(_item);
		
		// 11. Kernel
		_item = new HashMap<>(); _item.put("title", "Kernel Architecture"); _item.put("info", System.getProperty("os.arch")); listmap.add(_item);
		_item = new HashMap<>(); _item.put("title", "Kernel Version"); _item.put("info", System.getProperty("os.version")); listmap.add(_item);
		
		_item = new HashMap<>(); _item.put("title", "Tags"); _item.put("info", android.os.Build.TAGS); listmap.add(_item);
		_item = new HashMap<>(); _item.put("title", "Type"); _item.put("info", android.os.Build.TYPE); listmap.add(_item);
		
		// 12. Google Play Services & HMS
		String gms = "< Not Present >";
		try {
			android.content.pm.PackageInfo pInfo = getPackageManager().getPackageInfo("com.google.android.gms", 0);
			gms = pInfo.versionName;
		} catch (Exception e) {}
		_item = new HashMap<>(); _item.put("title", "Google Play Services Version"); _item.put("info", gms); listmap.add(_item);
		
		String hms = "< Not Present >";
		try {
			android.content.pm.PackageInfo pInfo = getPackageManager().getPackageInfo("com.huawei.hwid", 0);
			hms = pInfo.versionName;
		} catch (Exception e) {}
		_item = new HashMap<>(); _item.put("title", "Huawei Mobile Services Version"); _item.put("info", hms); listmap.add(_item);
		
		// 13. SSL, ZLib & Language
		_item = new HashMap<>(); _item.put("title", "OpenSSL Version"); _item.put("info", "OpenSSL 1.1.1 (compatible; BoringSSL)"); listmap.add(_item);
		_item = new HashMap<>(); _item.put("title", "ZLib Version"); _item.put("info", "1.3.1"); listmap.add(_item);
		
		// 14. ICU Versions
		String icuCldr = "46.0", icuLib = "76.1", icuUni = "16.0"; 
		try {
			Class<?> versionInfoClass = Class.forName("android.icu.util.VersionInfo");
			icuLib = versionInfoClass.getField("ICU_VERSION").get(null).toString();
			icuUni = versionInfoClass.getField("UNICODE_VERSION").get(null).toString();
		} catch (Exception e) {}
		_item = new HashMap<>(); _item.put("title", "ICU CLDR Version"); _item.put("info", icuCldr); listmap.add(_item);
		_item = new HashMap<>(); _item.put("title", "ICU Library Version"); _item.put("info", icuLib); listmap.add(_item);
		_item = new HashMap<>(); _item.put("title", "ICU Unicode Version"); _item.put("info", icuUni); listmap.add(_item);
		
		java.util.Locale locale = java.util.Locale.getDefault();
		_item = new HashMap<>(); _item.put("title", "Android Language"); _item.put("info", locale.getDisplayLanguage() + " (" + locale.getDisplayCountry() + ")"); listmap.add(_item);
		
		// 15. Time Zone
		java.util.TimeZone tz = java.util.TimeZone.getDefault();
		long offsetMillis = tz.getOffset(System.currentTimeMillis());
		String offset = String.format("%02d:%02d", Math.abs(offsetMillis / 3600000), Math.abs((offsetMillis / 60000) % 60));
		offset = (offsetMillis >= 0 ? "+" : "-") + offset;
		_item = new HashMap<>(); _item.put("title", "Configured Time Zone"); _item.put("info", tz.getDisplayName() + " (UTC" + offset + ")"); listmap.add(_item);
		
		// 16. UpTime (প্লেসহোল্ডার)
		_item = new HashMap<>(); _item.put("title", "UpTime"); _item.put("info", "Loading..."); listmap.add(_item);
		binding.listview1.setAdapter(new Listview1Adapter(listmap));
		timer = new TimerTask() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						long uptimeMillis = android.os.SystemClock.elapsedRealtime();
						long days = java.util.concurrent.TimeUnit.MILLISECONDS.toDays(uptimeMillis);
						uptimeMillis -= java.util.concurrent.TimeUnit.DAYS.toMillis(days);
						long hours = java.util.concurrent.TimeUnit.MILLISECONDS.toHours(uptimeMillis);
						uptimeMillis -= java.util.concurrent.TimeUnit.HOURS.toMillis(hours);
						long minutes = java.util.concurrent.TimeUnit.MILLISECONDS.toMinutes(uptimeMillis);
						uptimeMillis -= java.util.concurrent.TimeUnit.MINUTES.toMillis(minutes);
						long seconds = java.util.concurrent.TimeUnit.MILLISECONDS.toSeconds(uptimeMillis);
						
						String uptimeStr = "";
						if (days > 0) uptimeStr += days + " days, ";
						uptimeStr += String.format("%02d:%02d:%02d", hours, minutes, seconds);
						
						// শুধু লিস্টের একদম শেষের আইটেমটা (UpTime) লাইভ আপডেট করবে
						if(listmap.size() > 0){
							listmap.get(listmap.size() - 1).put("info", uptimeStr);
						}
						
						((BaseAdapter)binding.listview1.getAdapter()).notifyDataSetChanged();
					}
				});
			}
		};
		_timer.scheduleAtFixedRate(timer, (int)(0), (int)(1000));
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			InfoRowBinding binding = InfoRowBinding.inflate(getLayoutInflater());
			View _view = binding.getRoot();
			
			binding.textview1.setText(listmap.get((int)_position).get("title").toString());
			binding.textview2.setText(listmap.get((int)_position).get("info").toString());
			
			return _view;
		}
	}
}