package com.my.newproject7;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ListView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.android.material.appbar.AppBarLayout;
import com.my.newproject7.databinding.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class CpuActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private CpuBinding binding;
	
	private ArrayList<HashMap<String, Object>> listmap = new ArrayList<>();
	
	private TimerTask timer;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		binding = CpuBinding.inflate(getLayoutInflater());
		setContentView(binding.getRoot());
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		setSupportActionBar(binding.Toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		binding.Toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
	}
	
	private void initializeLogic() {
		timer = new TimerTask() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						android.widget.ListView _lv = (android.widget.ListView) findViewById(R.id.listview1);
						int _index = _lv.getFirstVisiblePosition();
						android.view.View _v = _lv.getChildAt(0);
						int _top = (_v == null) ? 0 : (_v.getTop() - _lv.getPaddingTop());
						
						listmap.clear();
						HashMap<String, Object> _item;
						String boardName = android.os.Build.BOARD;
						String socName = boardName;
						String nmProcess = "Unknown";
						
						// AIDA64-এর মতো ডাটাবেজ লজিক (আপনার ফোনের জন্য)
						if(boardName.toLowerCase().contains("pineapple") || boardName.toLowerCase().contains("e3q")) {
							socName = "Qualcomm Snapdragon 8 Gen 3 (SM8650)";
							nmProcess = "4 nm";
						}
						
						_item = new HashMap<>();
						_item.put("title", "SoC Model");
						_item.put("info", socName);
						listmap.add(_item);
						
						_item = new HashMap<>();
						_item.put("title", "Manufacturing Process");
						_item.put("info", nmProcess);
						listmap.add(_item);
						
						_item = new HashMap<>();
						_item.put("title", "Hardware / Board");
						_item.put("info", boardName);
						listmap.add(_item);
						
						_item = new HashMap<>();
						_item.put("title", "Instruction Set");
						_item.put("info", System.getProperty("os.arch"));
						listmap.add(_item);
						
						int cores = Runtime.getRuntime().availableProcessors();
						_item = new HashMap<>();
						_item.put("title", "CPU Cores");
						_item.put("info", String.valueOf(cores));
						listmap.add(_item);
						
						// Scaling Governor বের করার কোড
						String governor = "Unknown";
						try {
							java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.FileReader("/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor"));
							governor = reader.readLine();
							reader.close();
						} catch (Exception e) {}
						
						_item = new HashMap<>();
						_item.put("title", "Scaling Governor");
						_item.put("info", governor);
						listmap.add(_item);
						
						// Live Core Clocks
						for (int i = 0; i < cores; i++) {
							String clock = "Stopped / Sleeping";
							try {
								java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.FileReader("/sys/devices/system/cpu/cpu" + i + "/cpufreq/scaling_cur_freq"));
								String line = reader.readLine();
								if(line != null) {
									long freq = Long.parseLong(line) / 1000;
									clock = freq + " MHz";
								}
								reader.close();
							} catch (Exception e) {}
							
							_item = new HashMap<>();
							_item.put("title", "Core " + (i + 1) + " Clock");
							_item.put("info", clock);
							listmap.add(_item);
						}
						
						_item = new HashMap<>();
						_item.put("title", "Supported ABIs");
						if(android.os.Build.SUPPORTED_ABIS.length > 0){
							_item.put("info", android.os.Build.SUPPORTED_ABIS[0]);
						} else {
							_item.put("info", android.os.Build.CPU_ABI);
						}
						listmap.add(_item);
						binding.listview1.setAdapter(new Listview1Adapter(listmap));
						((BaseAdapter)binding.listview1.getAdapter()).notifyDataSetChanged();
						android.widget.ListView _lv2 = (android.widget.ListView) findViewById(R.id.listview1);
						_lv2.setSelectionFromTop(_index, _top);
						
					}
				});
			}
		};
		_timer.scheduleAtFixedRate(timer, (int)(0), (int)(1000));
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			InfoRowBinding binding = InfoRowBinding.inflate(getLayoutInflater());
			View _view = binding.getRoot();
			
			binding.textview1.setText(listmap.get((int)_position).get("title").toString());
			binding.textview2.setText(listmap.get((int)_position).get("info").toString());
			
			return _view;
		}
	}
}