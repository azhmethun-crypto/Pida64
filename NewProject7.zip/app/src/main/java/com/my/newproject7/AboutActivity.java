package com.my.newproject7;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ListView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.android.material.appbar.AppBarLayout;
import com.my.newproject7.databinding.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class AboutActivity extends AppCompatActivity {
	
	private AboutBinding binding;
	
	private ArrayList<HashMap<String, Object>> about_map = new ArrayList<>();
	
	private Intent tg = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		binding = AboutBinding.inflate(getLayoutInflater());
		setContentView(binding.getRoot());
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		setSupportActionBar(binding.Toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		binding.Toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		
		binding.listview1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				if (_position == 2) {
					tg.setAction(Intent.ACTION_VIEW);
					tg.setData(Uri.parse("https://t.me/UNDERCOVERITFIRM_GROUP"));
					startActivity(tg);
				}
			}
		});
	}
	
	private void initializeLogic() {
		about_map.clear();
		
		String[] titles = {
			"Pida64 for Android",
			"Technical support",
			"Submit report",
			"Copyright"
		};
		
		String[] subtitles = {
			"Version 1.0.0",
			"Join the UITF community.",
			"Send us your report to help us fix bugs and further improve Pida64.",
			"© 2026 Undercover IT Firm. All Rights Reserved."
		};
		
		for(int i = 0; i < titles.length; i++) {
			java.util.HashMap<String, Object> item = new java.util.HashMap<>();
			item.put("title", titles[i]);
			item.put("value", subtitles[i]);
			about_map.add(item);
		}
		binding.listview1.setAdapter(new Listview1Adapter(about_map));
		((BaseAdapter)binding.listview1.getAdapter()).notifyDataSetChanged();
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			AboutRowBinding binding = AboutRowBinding.inflate(getLayoutInflater());
			View _view = binding.getRoot();
			
			binding.textview1.setText(about_map.get((int)_position).get("title").toString());
			binding.textview2.setText(about_map.get((int)_position).get("value").toString());
			
			return _view;
		}
	}
}