package com.my.newproject7;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ListView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.android.material.appbar.AppBarLayout;
import com.my.newproject7.databinding.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class AppsActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private AppsBinding binding;
	
	private ArrayList<HashMap<String, Object>> listmap = new ArrayList<>();
	
	private TimerTask timer;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		binding = AppsBinding.inflate(getLayoutInflater());
		setContentView(binding.getRoot());
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		setSupportActionBar(binding.Toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		binding.Toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
	}
	
	private void initializeLogic() {
		final android.app.ProgressDialog pd = new android.app.ProgressDialog(AppsActivity.this);
		pd.setMessage("Loading Apps...");
		pd.setCancelable(false);
		pd.show();
		
		timer = new TimerTask() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						android.content.pm.PackageManager pm = getPackageManager();
						java.util.List<android.content.pm.PackageInfo> packs = pm.getInstalledPackages(0);
						
						// ১. সিস্টেম থেকে সব অ্যাপ বের করা
						for(int i = 0; i < packs.size(); i++) {
							android.content.pm.PackageInfo p = packs.get(i);
							android.content.pm.ApplicationInfo a = p.applicationInfo;
							
							try {
								String appName = a.loadLabel(pm).toString();
								android.graphics.drawable.Drawable icon = a.loadIcon(pm);
								String version = p.versionName != null ? p.versionName : "Unknown";
								
								HashMap<String, Object> map = new HashMap<>();
								map.put("name", appName);
								map.put("version", "Version " + version);
								map.put("package", p.packageName);
								map.put("icon", icon); 
								listmap.add(map);
							} catch (Exception e) {}
						}
						
						// ২. অ্যাপের নাম অনুযায়ী (A-Z) সাজানো
						java.util.Collections.sort(listmap, new java.util.Comparator<HashMap<String, Object>>() {
							public int compare(HashMap<String, Object> m1, HashMap<String, Object> m2) {
								return m1.get("name").toString().compareToIgnoreCase(m2.get("name").toString());
							}
						});
						
						// ৩. সেফটি চেক (যদি সিকিউরিটির কারণে লিস্ট ব্লক হয়)
						if (listmap.isEmpty()) {
							HashMap<String, Object> map = new HashMap<>();
							map.put("name", "Permission Blocked by Android");
							map.put("version", "Android Security Restriction");
							map.put("package", "Need QUERY_ALL_PACKAGES permission");
							listmap.add(map);
						}
						
						binding.listview1.setAdapter(new Listview1Adapter(listmap));
						((BaseAdapter)binding.listview1.getAdapter()).notifyDataSetChanged();
						pd.dismiss();
						
					}
				});
			}
		};
		_timer.schedule(timer, (int)(100));
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			AppRowBinding binding = AppRowBinding.inflate(getLayoutInflater());
			View _view = binding.getRoot();
			
			// কাস্টম ভিউয়ের জিনিসগুলো আইডির সাহায্যে কোডের সাথে কানেক্ট করা
			TextView t1 = (TextView) _view.findViewById(R.id.textview1);
			TextView t2 = (TextView) _view.findViewById(R.id.textview2);
			TextView t3 = (TextView) _view.findViewById(R.id.textview3);
			ImageView i1 = (ImageView) _view.findViewById(R.id.imageview1);
			
			try {
				// এখানে position-এর জায়গায় _position দেওয়া হয়েছে
				t1.setText(listmap.get((int)_position).get("name").toString());
				t2.setText(listmap.get((int)_position).get("version").toString());
				t3.setText(listmap.get((int)_position).get("package").toString());
				
				// লেখার কালার এবং স্টাইল
				t1.setTextColor(android.graphics.Color.WHITE);
				t1.setTypeface(null, android.graphics.Typeface.BOLD); 
				t2.setTextColor(android.graphics.Color.LTGRAY);
				t3.setTextColor(android.graphics.Color.GRAY);
				
				// লোগো বা আইকন বসানো হচ্ছে
				Object img = listmap.get((int)_position).get("icon");
				if(img != null && img instanceof android.graphics.drawable.Drawable) {
					i1.setImageDrawable((android.graphics.drawable.Drawable)img);
				}
			} catch(Exception e) {}
			
			return _view;
		}
	}
}