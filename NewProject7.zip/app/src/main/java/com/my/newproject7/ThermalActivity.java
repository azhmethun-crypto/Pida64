package com.my.newproject7;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ListView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.android.material.appbar.AppBarLayout;
import com.my.newproject7.databinding.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class ThermalActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private ThermalBinding binding;
	
	private ArrayList<HashMap<String, Object>> listmap = new ArrayList<>();
	
	private TimerTask timer;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		binding = ThermalBinding.inflate(getLayoutInflater());
		setContentView(binding.getRoot());
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		setSupportActionBar(binding.Toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		binding.Toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
	}
	
	private void initializeLogic() {
		binding.listview1.setAdapter(new Listview1Adapter(listmap));
		timer = new TimerTask() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						java.io.File dir = new java.io.File("/sys/class/thermal/");
						if (dir.exists() && dir.isDirectory()) {
							java.io.File[] files = dir.listFiles();
							if (files != null) {
								int index = 0;
								for (java.io.File file : files) {
									if (file.isDirectory() && file.getName().startsWith("thermal_zone")) {
										try {
											// সেন্সরের নাম এবং তাপমাত্রা পড়া হচ্ছে
											String type = new java.util.Scanner(new java.io.File(file, "type")).useDelimiter("\\A").next().trim();
											String tempStr = new java.util.Scanner(new java.io.File(file, "temp")).useDelimiter("\\A").next().trim();
											float temp = Float.parseFloat(tempStr);
											
											// সিস্টেম থেকে পাওয়া ডাটাকে সেলসিয়াসে কনভার্ট করা
											if(temp > 1000) temp = temp / 1000.0f; 
											else if(temp > 100) temp = temp / 10.0f;
											
											// আজেবাজে বা ভুল ডাটা ফিল্টার করা
											if (temp > -30 && temp < 150) {
												// স্ক্রল যেন লাফিয়ে না ওঠে, তাই আপডেট লজিক
												if(index < listmap.size()) {
													listmap.get(index).put("title", type);
													listmap.get(index).put("info", String.format("%.1f°C", temp));
												} else {
													HashMap<String, Object> _item = new HashMap<>();
													_item.put("title", type);
													_item.put("info", String.format("%.1f°C", temp));
													listmap.add(_item);
												}
												index++;
											}
										} catch (Exception e) {
											// পারমিশন না থাকলে স্কিপ করবে
										}
									}
								}
								// অতিরিক্ত আইটেম থাকলে মুছে ফেলবে
								while(listmap.size() > index) {
									listmap.remove(listmap.size() - 1);
								}
							}
						}
						
						// যদি নতুন অ্যান্ড্রয়েড ভার্সন সিকিউরিটির জন্য ব্লক করে দেয়
						if (listmap.isEmpty()) {
							HashMap<String, Object> _item = new HashMap<>();
							_item.put("title", "Thermal Sensors");
							_item.put("info", "Access Restricted by Android OS");
							listmap.add(_item);
						}
						
						((BaseAdapter)binding.listview1.getAdapter()).notifyDataSetChanged();
					}
				});
			}
		};
		_timer.scheduleAtFixedRate(timer, (int)(0), (int)(1500));
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			InfoRowBinding binding = InfoRowBinding.inflate(getLayoutInflater());
			View _view = binding.getRoot();
			
			binding.textview1.setText(listmap.get((int)_position).get("title").toString());
			binding.textview2.setText(listmap.get((int)_position).get("info").toString());
			
			return _view;
		}
	}
}