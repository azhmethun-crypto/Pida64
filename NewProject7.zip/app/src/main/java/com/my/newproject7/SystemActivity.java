package com.my.newproject7;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ListView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.android.material.appbar.AppBarLayout;
import com.my.newproject7.databinding.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class SystemActivity extends AppCompatActivity {
	
	private SystemBinding binding;
	
	private ArrayList<HashMap<String, Object>> listmap = new ArrayList<>();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		binding = SystemBinding.inflate(getLayoutInflater());
		setContentView(binding.getRoot());
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		setSupportActionBar(binding.Toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		binding.Toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
	}
	
	private void initializeLogic() {
		HashMap<String, Object> _item = new HashMap<>();
		
		_item = new HashMap<>();
		_item.put("title", "Manufacturer");
		_item.put("info", android.os.Build.MANUFACTURER);
		listmap.add(_item);
		
		_item = new HashMap<>();
		_item.put("title", "Model");
		_item.put("info", android.os.Build.MODEL);
		listmap.add(_item);
		
		_item = new HashMap<>();
		_item.put("title", "Brand");
		_item.put("info", android.os.Build.BRAND);
		listmap.add(_item);
		
		_item = new HashMap<>();
		_item.put("title", "Board");
		_item.put("info", android.os.Build.BOARD);
		listmap.add(_item);
		
		_item = new HashMap<>();
		_item.put("title", "Device");
		_item.put("info", android.os.Build.DEVICE);
		listmap.add(_item);
		
		_item = new HashMap<>();
		_item.put("title", "Hardware");
		_item.put("info", android.os.Build.HARDWARE);
		listmap.add(_item);
		
		_item = new HashMap<>();
		_item.put("title", "Product");
		_item.put("info", android.os.Build.PRODUCT);
		listmap.add(_item);
		
		// RAM Calculation
		android.app.ActivityManager actManager = (android.app.ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
		android.app.ActivityManager.MemoryInfo memInfo = new android.app.ActivityManager.MemoryInfo();
		actManager.getMemoryInfo(memInfo);
		
		double totalRam = (double) memInfo.totalMem / (1024 * 1024 * 1024);
		double availRam = (double) memInfo.availMem / (1024 * 1024 * 1024);
		
		_item = new HashMap<>();
		_item.put("title", "Total Memory");
		_item.put("info", String.format("%.2f GB", totalRam));
		listmap.add(_item);
		
		_item = new HashMap<>();
		_item.put("title", "Available Memory");
		_item.put("info", String.format("%.2f GB", availRam));
		listmap.add(_item);
		
		// Storage Calculation
		java.io.File path = android.os.Environment.getDataDirectory();
		android.os.StatFs stat = new android.os.StatFs(path.getPath());
		long blockSize = stat.getBlockSizeLong();
		long totalBlocks = stat.getBlockCountLong();
		long availableBlocks = stat.getAvailableBlocksLong();
		
		double totalStorage = (double) (totalBlocks * blockSize) / (1024 * 1024 * 1024);
		double freeStorage = (double) (availableBlocks * blockSize) / (1024 * 1024 * 1024);
		
		_item = new HashMap<>();
		_item.put("title", "Internal Storage Total");
		_item.put("info", String.format("%.2f GB", totalStorage));
		listmap.add(_item);
		
		_item = new HashMap<>();
		_item.put("title", "Internal Storage Free");
		_item.put("info", String.format("%.2f GB", freeStorage));
		listmap.add(_item);
		binding.listview2.setAdapter(new Listview2Adapter(listmap));
		((BaseAdapter)binding.listview2.getAdapter()).notifyDataSetChanged();
	}
	
	public class Listview2Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview2Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			InfoRowBinding binding = InfoRowBinding.inflate(getLayoutInflater());
			View _view = binding.getRoot();
			
			binding.textview1.setText(listmap.get((int)_position).get("title").toString());
			binding.textview2.setText(listmap.get((int)_position).get("info").toString());
			
			return _view;
		}
	}
}