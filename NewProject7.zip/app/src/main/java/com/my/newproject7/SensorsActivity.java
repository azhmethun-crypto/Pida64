package com.my.newproject7;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ListView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.android.material.appbar.AppBarLayout;
import com.my.newproject7.databinding.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class SensorsActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private SensorsBinding binding;
	
	private ArrayList<HashMap<String, Object>> listmap = new ArrayList<>();
	
	private TimerTask timer;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		binding = SensorsBinding.inflate(getLayoutInflater());
		setContentView(binding.getRoot());
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		setSupportActionBar(binding.Toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		binding.Toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
	}
	
	private void initializeLogic() {
		final android.hardware.SensorManager sm = (android.hardware.SensorManager) getSystemService(android.content.Context.SENSOR_SERVICE);
		java.util.List<android.hardware.Sensor> sList = sm.getSensorList(android.hardware.Sensor.TYPE_ALL);
		
		final java.util.HashMap<String, Integer> sMap = new java.util.HashMap<>();
		
		// ১. লিস্ট তৈরি করা
		for (int i = 0; i < sList.size(); i++) {
			android.hardware.Sensor s = sList.get(i);
			HashMap<String, Object> item = new HashMap<>();
			
			String wake = "";
			if (android.os.Build.VERSION.SDK_INT >= 21) {
				wake = s.isWakeUpSensor() ? "\nWakeup" : "\nNon-wakeup";
			}
			
			// নাম থেকে অতিরিক্ত Wakeup মুছে ফেলা হচ্ছে যাতে ডাবল না হয়
			String cleanName = s.getName().replace(" Wakeup", "").replace(" Non-wakeup", "");
			
			item.put("title", cleanName + wake);
			item.put("info", ""); // Loading-এর বদলে একদম ফাঁকা রাখা হলো
			listmap.add(item);
			
			sMap.put(cleanName + wake, i); 
		}
		
		// ২. ডাটা আপডেট লিসেনার
		android.hardware.SensorEventListener sListener = new android.hardware.SensorEventListener() {
			@Override
			public void onSensorChanged(android.hardware.SensorEvent e) {
				String w = "";
				if (android.os.Build.VERSION.SDK_INT >= 21) {
					w = e.sensor.isWakeUpSensor() ? "\nWakeup" : "\nNon-wakeup";
				}
				
				String cleanName = e.sensor.getName().replace(" Wakeup", "").replace(" Non-wakeup", "");
				Integer idx = sMap.get(cleanName + w);
				
				if (idx != null && idx < listmap.size()) {
					float[] v = e.values;
					String val = "";
					int t = e.sensor.getType();
					
					// Orientation Sensor (টাইপ ৩) এর জন্য বিশেষ ফরম্যাট
					if (t == 3) {
						if (v.length >= 3) val = String.format("Azimuth: %.1f / Pitch: %.1f / Roll: %.1f", v[0], v[1], v[2]);
					} else {
						if (v.length >= 3) {
							val = String.format("x: %.1f / y: %.1f / z: %.1f", v[0], v[1], v[2]);
						} else if (v.length == 2) {
							val = String.format("x: %.1f / y: %.1f", v[0], v[1]);
						} else if (v.length >= 1) {
							val = String.format("%.1f", v[0]);
						}
					}
					
					// ইউনিট বসানো
					if(t == 1 || t == 9 || t == 10) val += " m/s²";
					else if(t == 2 || t == 14) val += " µT";
					else if(t == 4 || t == 16) val += " rad/s";
					else if(t == 5) val += " lux";
					else if(t == 6) val += " hPa";
					else if(t == 8) val += " cm"; // Proximity
					
					listmap.get(idx).put("info", val);
				}
			}
			@Override
			public void onAccuracyChanged(android.hardware.Sensor s, int a) {}
		};
		
		for (android.hardware.Sensor s : sList) {
			sm.registerListener(sListener, s, android.hardware.SensorManager.SENSOR_DELAY_UI);
		}
		binding.listview1.setAdapter(new Listview1Adapter(listmap));
		timer = new TimerTask() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						((BaseAdapter)binding.listview1.getAdapter()).notifyDataSetChanged();
					}
				});
			}
		};
		_timer.scheduleAtFixedRate(timer, (int)(0), (int)(300));
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			InfoRowBinding binding = InfoRowBinding.inflate(getLayoutInflater());
			View _view = binding.getRoot();
			
			binding.textview1.setText(listmap.get((int)_position).get("title").toString());
			binding.textview2.setText(listmap.get((int)_position).get("info").toString());
			
			return _view;
		}
	}
}