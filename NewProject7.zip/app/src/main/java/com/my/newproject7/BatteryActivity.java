package com.my.newproject7;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ListView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.android.material.appbar.AppBarLayout;
import com.my.newproject7.databinding.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class BatteryActivity extends AppCompatActivity {
	
	private BatteryBinding binding;
	
	private ArrayList<HashMap<String, Object>> listmap = new ArrayList<>();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		binding = BatteryBinding.inflate(getLayoutInflater());
		setContentView(binding.getRoot());
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		setSupportActionBar(binding.Toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		binding.Toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
	}
	
	private void initializeLogic() {
		HashMap<String, Object> _item;
		android.content.IntentFilter ifilter = new android.content.IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED);
		android.content.Intent batteryStatus = getApplicationContext().registerReceiver(null, ifilter);
		android.os.BatteryManager batManager = (android.os.BatteryManager) getSystemService(android.content.Context.BATTERY_SERVICE);
		
		if (batteryStatus != null) {
			// 1. Power Source
			int chargePlug = batteryStatus.getIntExtra(android.os.BatteryManager.EXTRA_PLUGGED, -1);
			String plugString = "Battery";
			if (chargePlug == android.os.BatteryManager.BATTERY_PLUGGED_USB) plugString = "USB Charger";
			else if (chargePlug == android.os.BatteryManager.BATTERY_PLUGGED_AC) plugString = "AC Charger";
			else if (chargePlug == android.os.BatteryManager.BATTERY_PLUGGED_WIRELESS) plugString = "Wireless";
			_item = new HashMap<>(); _item.put("title", "Power Source"); _item.put("info", plugString); listmap.add(_item);
			
			// 2. Level
			int level = batteryStatus.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1);
			int scale = batteryStatus.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, -1);
			float batteryPct = level * 100 / (float)scale;
			_item = new HashMap<>(); _item.put("title", "Level"); _item.put("info", (int)batteryPct + " %"); listmap.add(_item);
			
			// 3. Status
			int status = batteryStatus.getIntExtra(android.os.BatteryManager.EXTRA_STATUS, -1);
			String statusString = "Unknown";
			switch (status) {
				case android.os.BatteryManager.BATTERY_STATUS_CHARGING: statusString = "Charging"; break;
				case android.os.BatteryManager.BATTERY_STATUS_DISCHARGING: statusString = "Discharging"; break;
				case android.os.BatteryManager.BATTERY_STATUS_FULL: statusString = "Full"; break;
				case android.os.BatteryManager.BATTERY_STATUS_NOT_CHARGING: statusString = "Not Charging"; break;
			}
			_item = new HashMap<>(); _item.put("title", "Status"); _item.put("info", statusString); listmap.add(_item);
			
			// 4. Health
			int health = batteryStatus.getIntExtra(android.os.BatteryManager.EXTRA_HEALTH, -1);
			String healthString = "Unknown";
			switch (health) {
				case android.os.BatteryManager.BATTERY_HEALTH_GOOD: healthString = "Good"; break;
				case android.os.BatteryManager.BATTERY_HEALTH_OVERHEAT: healthString = "Overheat"; break;
				case android.os.BatteryManager.BATTERY_HEALTH_DEAD: healthString = "Dead"; break;
				case android.os.BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE: healthString = "Over Voltage"; break;
				case android.os.BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE: healthString = "Unspecified Failure"; break;
				case android.os.BatteryManager.BATTERY_HEALTH_COLD: healthString = "Cold"; break;
			}
			_item = new HashMap<>(); _item.put("title", "Health"); _item.put("info", healthString); listmap.add(_item);
			
			// 5. Technology
			String technology = batteryStatus.getStringExtra(android.os.BatteryManager.EXTRA_TECHNOLOGY);
			_item = new HashMap<>(); _item.put("title", "Technology"); _item.put("info", technology != null ? technology : "Unknown"); listmap.add(_item);
			
			// 6. Temperature
			int temp = batteryStatus.getIntExtra(android.os.BatteryManager.EXTRA_TEMPERATURE, -1);
			float tempC = temp / 10.0f;
			_item = new HashMap<>(); _item.put("title", "Temperature"); _item.put("info", tempC + "°C"); listmap.add(_item);
			
			// 7. Voltage (mV থেকে V তে কনভার্ট করা হলো)
			int voltage = batteryStatus.getIntExtra(android.os.BatteryManager.EXTRA_VOLTAGE, -1);
			float voltV = voltage / 1000.0f;
			_item = new HashMap<>(); _item.put("title", "Voltage"); _item.put("info", String.format("%.3f V", voltV)); listmap.add(_item);
			
			// 8. Charge Counter (mAh)
			int chargeCounter = 0;
			if (android.os.Build.VERSION.SDK_INT >= 21) {
				chargeCounter = batManager.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER);
			}
			int ccMah = chargeCounter / 1000;
			if (ccMah < 0) ccMah = 0;
			_item = new HashMap<>(); _item.put("title", "Charge Counter"); _item.put("info", ccMah + " mAh"); listmap.add(_item);
			
			// 9. Discharge Rate (mA)
			int currentNow = 0;
			if (android.os.Build.VERSION.SDK_INT >= 21) {
				currentNow = batManager.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CURRENT_NOW);
			}
			int rateMa = Math.abs(currentNow / 1000);
			_item = new HashMap<>(); _item.put("title", "Discharge Rate"); _item.put("info", rateMa + " mA"); listmap.add(_item);
			
			// 10. Charging Cycles
			_item = new HashMap<>(); _item.put("title", "Charging Cycles"); _item.put("info", "0"); listmap.add(_item);
			
			// 11. Remaining Battery Time
			_item = new HashMap<>(); _item.put("title", "Remaining Battery Time"); _item.put("info", "N/A"); listmap.add(_item);
			
			// 12. Capacity (Reported by Android - Hidden API দিয়ে বের করা হচ্ছে)
			long capacity = 0;
			try {
				Object mPowerProfile = Class.forName("com.android.internal.os.PowerProfile").getConstructor(android.content.Context.class).newInstance(this);
				capacity = Math.round((Double) Class.forName("com.android.internal.os.PowerProfile").getMethod("getBatteryCapacity").invoke(mPowerProfile));
			} catch (Exception e) {}
			_item = new HashMap<>(); _item.put("title", "Capacity (Reported by Android)"); _item.put("info", capacity > 0 ? capacity + " mAh" : "Unknown"); listmap.add(_item);
			
			// 13. Capacity (From Database - রাউন্ডিং করা হচ্ছে)
			long capDb = (long) (Math.ceil(capacity / 100.0) * 100);
			if (capacity > 4800 && capacity <= 5000) capDb = 5000;
			_item = new HashMap<>(); _item.put("title", "Capacity (From Database)"); _item.put("info", capDb > 0 ? capDb + " mAh" : "Unknown"); listmap.add(_item);
		}
		binding.listview1.setAdapter(new Listview1Adapter(listmap));
		((BaseAdapter)binding.listview1.getAdapter()).notifyDataSetChanged();
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			InfoRowBinding binding = InfoRowBinding.inflate(getLayoutInflater());
			View _view = binding.getRoot();
			
			binding.textview1.setText(listmap.get((int)_position).get("title").toString());
			binding.textview2.setText(listmap.get((int)_position).get("info").toString());
			if (listmap.get((int)_position).get("info").toString().equals("")) {
				binding.textview2.setVisibility(View.GONE);
				binding.textview1.setGravity(Gravity.CENTER_VERTICAL | Gravity.CENTER_HORIZONTAL);
				binding.textview1.setTypeface(Typeface.DEFAULT, 1);
			} else {
				binding.textview2.setVisibility(View.VISIBLE);
				binding.textview1.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
				binding.textview1.setTypeface(Typeface.DEFAULT, 0);
			}
			
			return _view;
		}
	}
}