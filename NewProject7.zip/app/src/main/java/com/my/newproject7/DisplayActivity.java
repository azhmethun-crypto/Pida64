package com.my.newproject7;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ListView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.android.material.appbar.AppBarLayout;
import com.my.newproject7.databinding.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class DisplayActivity extends AppCompatActivity {
	
	private DisplayBinding binding;
	
	private ArrayList<HashMap<String, Object>> listmap = new ArrayList<>();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		binding = DisplayBinding.inflate(getLayoutInflater());
		setContentView(binding.getRoot());
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		setSupportActionBar(binding.Toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		binding.Toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
	}
	
	private void initializeLogic() {
		HashMap<String, Object> _item;
		android.util.DisplayMetrics metrics = new android.util.DisplayMetrics();
		getWindowManager().getDefaultDisplay().getRealMetrics(metrics);
		
		int width = metrics.widthPixels;
		int height = metrics.heightPixels;
		
		// Screen Resolution
		_item = new HashMap<>();
		_item.put("title", "Screen Resolution");
		_item.put("info", height + " x " + width); 
		listmap.add(_item);
		
		// Refresh Rate
		android.view.Display display = getWindowManager().getDefaultDisplay();
		_item = new HashMap<>();
		_item.put("title", "Refresh Rate");
		_item.put("info", String.format("%.2f", display.getRefreshRate()) + " Hz");
		listmap.add(_item);
		
		// Pixel Density
		_item = new HashMap<>();
		_item.put("title", "Pixel Density");
		_item.put("info", metrics.densityDpi + " dpi");
		listmap.add(_item);
		
		// xdpi / ydpi
		_item = new HashMap<>();
		_item.put("title", "xdpi / ydpi");
		_item.put("info", String.format("%.0f", metrics.xdpi) + " / " + String.format("%.0f", metrics.ydpi) + " dpi");
		listmap.add(_item);
		
		// Screen Diagonal
		float widthInches = metrics.widthPixels / metrics.xdpi;
		float heightInches = metrics.heightPixels / metrics.ydpi;
		double diagonalInches = Math.sqrt(Math.pow(widthInches, 2) + Math.pow(heightInches, 2));
		
		_item = new HashMap<>();
		_item.put("title", "Screen Diagonal");
		_item.put("info", String.format("%.2f", diagonalInches) + " inches");
		listmap.add(_item);
		
		// OpenGL ES Version
		android.app.ActivityManager activityManager = (android.app.ActivityManager) getSystemService(android.content.Context.ACTIVITY_SERVICE);
		android.content.pm.ConfigurationInfo configurationInfo = activityManager.getDeviceConfigurationInfo();
		_item = new HashMap<>();
		_item.put("title", "OpenGL ES Version");
		_item.put("info", configurationInfo.getGlEsVersion());
		listmap.add(_item);
		
		// --- GPU and Extensions Magic Code ---
		String gpuVendor = "Unknown";
		String gpuRenderer = "Unknown";
		String glExtensions = "Not Supported";
		
		try {
			javax.microedition.khronos.egl.EGL10 egl = (javax.microedition.khronos.egl.EGL10) javax.microedition.khronos.egl.EGLContext.getEGL();
			javax.microedition.khronos.egl.EGLDisplay eglDisplay = egl.eglGetDisplay(javax.microedition.khronos.egl.EGL10.EGL_DEFAULT_DISPLAY);
			int[] version = new int[2];
			egl.eglInitialize(eglDisplay, version);
			
			int[] configAttribs = {
				javax.microedition.khronos.egl.EGL10.EGL_SURFACE_TYPE, javax.microedition.khronos.egl.EGL10.EGL_PBUFFER_BIT,
				javax.microedition.khronos.egl.EGL10.EGL_BLUE_SIZE, 8,
				javax.microedition.khronos.egl.EGL10.EGL_GREEN_SIZE, 8,
				javax.microedition.khronos.egl.EGL10.EGL_RED_SIZE, 8,
				javax.microedition.khronos.egl.EGL10.EGL_RENDERABLE_TYPE, 4,
				javax.microedition.khronos.egl.EGL10.EGL_NONE
			};
			javax.microedition.khronos.egl.EGLConfig[] configs = new javax.microedition.khronos.egl.EGLConfig[1];
			int[] numConfigs = new int[1];
			egl.eglChooseConfig(eglDisplay, configAttribs, configs, 1, numConfigs);
			
			int[] contextAttribs = { 0x3098, 2, javax.microedition.khronos.egl.EGL10.EGL_NONE };
			javax.microedition.khronos.egl.EGLContext ctx = egl.eglCreateContext(eglDisplay, configs[0], javax.microedition.khronos.egl.EGL10.EGL_NO_CONTEXT, contextAttribs);
			
			int[] surfaceAttribs = {
				javax.microedition.khronos.egl.EGL10.EGL_WIDTH, 1,
				javax.microedition.khronos.egl.EGL10.EGL_HEIGHT, 1,
				javax.microedition.khronos.egl.EGL10.EGL_NONE
			};
			javax.microedition.khronos.egl.EGLSurface surface = egl.eglCreatePbufferSurface(eglDisplay, configs[0], surfaceAttribs);
			egl.eglMakeCurrent(eglDisplay, surface, surface, ctx);
			
			gpuVendor = android.opengl.GLES20.glGetString(android.opengl.GLES20.GL_VENDOR);
			gpuRenderer = android.opengl.GLES20.glGetString(android.opengl.GLES20.GL_RENDERER);
			String rawExt = android.opengl.GLES20.glGetString(android.opengl.GLES20.GL_EXTENSIONS);
			
			if(rawExt != null) {
				glExtensions = rawExt.replace(" ", "\n");
			}
			
			egl.eglMakeCurrent(eglDisplay, javax.microedition.khronos.egl.EGL10.EGL_NO_SURFACE, javax.microedition.khronos.egl.EGL10.EGL_NO_SURFACE, javax.microedition.khronos.egl.EGL10.EGL_NO_CONTEXT);
			egl.eglDestroySurface(eglDisplay, surface);
			egl.eglDestroyContext(eglDisplay, ctx);
			egl.eglTerminate(eglDisplay);
		} catch (Exception e) {}
		
		_item = new HashMap<>();
		_item.put("title", "GPU Vendor");
		_item.put("info", gpuVendor);
		listmap.add(_item);
		
		_item = new HashMap<>();
		_item.put("title", "GPU Renderer");
		_item.put("info", gpuRenderer);
		listmap.add(_item);
		
		// স্পেশাল লজিক: এক্সটেনশনের জন্য info ফাঁকা রাখা হয়েছে
		_item = new HashMap<>();
		_item.put("title", "OpenGL ES Extensions:\n" + glExtensions);
		_item.put("info", "");
		listmap.add(_item);
		binding.listview1.setAdapter(new Listview1Adapter(listmap));
		((BaseAdapter)binding.listview1.getAdapter()).notifyDataSetChanged();
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			InfoRowBinding binding = InfoRowBinding.inflate(getLayoutInflater());
			View _view = binding.getRoot();
			
			binding.textview1.setText(listmap.get((int)_position).get("title").toString());
			binding.textview2.setText(listmap.get((int)_position).get("info").toString());
			if (listmap.get((int)_position).get("info").toString().equals("")) {
				binding.textview2.setVisibility(View.GONE);
			} else {
				binding.textview2.setVisibility(View.VISIBLE);
			}
			
			return _view;
		}
	}
}