package com.my.newproject7;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ListView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.android.material.appbar.AppBarLayout;
import com.my.newproject7.databinding.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class DirectoriesActivity extends AppCompatActivity {
	
	private DirectoriesBinding binding;
	
	private ArrayList<HashMap<String, Object>> dir_map = new ArrayList<>();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		binding = DirectoriesBinding.inflate(getLayoutInflater());
		setContentView(binding.getRoot());
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		setSupportActionBar(binding.Toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		binding.Toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
	}
	
	private void initializeLogic() {
		dir_map.clear();
		
		try {
			// ফোনের একদম ভেতরের রুট ফাইল স্ক্যান করা হচ্ছে
			java.io.BufferedReader br = new java.io.BufferedReader(new java.io.FileReader("/proc/mounts"));
			String line;
			
			while ((line = br.readLine()) != null) {
				String[] parts = line.split(" ");
				if (parts.length >= 4) {
					String device = parts[0];      // যেমন: /dev/block/dm-7
					String mountPoint = parts[1];  // যেমন: /
					String fsType = parts[2];      // যেমন: erofs বা ext4
					String flags = parts[3];       // পারমিশন
					
					// Read-Only নাকি Read-Write সেটা বের করা
					String access = "Read-Write";
					if (flags.startsWith("ro,") || flags.equals("ro")) {
						access = "Read-Only";
					}
					
					java.util.HashMap<String, Object> item = new java.util.HashMap<>();
					// বামদিকের ফোল্ডার/পাথ
					item.put("title", mountPoint); 
					// ডানদিকের ডিটেইলস (Device, File System, Access)
					item.put("value", "Device: " + device + "\nFile System: " + fsType + "\n" + access);
					
					dir_map.add(item);
				}
			}
			br.close();
		} catch (Exception e) {
			java.util.HashMap<String, Object> err = new java.util.HashMap<>();
			err.put("title", "Error");
			err.put("value", "Could not read mount points.");
			dir_map.add(err);
		}
		binding.listview1.setAdapter(new Listview1Adapter(dir_map));
		((BaseAdapter)binding.listview1.getAdapter()).notifyDataSetChanged();
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			InfoRowBinding binding = InfoRowBinding.inflate(getLayoutInflater());
			View _view = binding.getRoot();
			
			binding.textview1.setText(dir_map.get((int)_position).get("title").toString());
			binding.textview2.setText(dir_map.get((int)_position).get("value").toString());
			
			return _view;
		}
	}
}