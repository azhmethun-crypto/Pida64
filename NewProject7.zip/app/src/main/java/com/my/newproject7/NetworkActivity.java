package com.my.newproject7;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ListView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.android.material.appbar.AppBarLayout;
import com.my.newproject7.databinding.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class NetworkActivity extends AppCompatActivity {
	
	private NetworkBinding binding;
	
	private ArrayList<HashMap<String, Object>> listmap = new ArrayList<>();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		binding = NetworkBinding.inflate(getLayoutInflater());
		setContentView(binding.getRoot());
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		setSupportActionBar(binding.Toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		binding.Toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
	}
	
	private void initializeLogic() {
		HashMap<String, Object> _item;
		android.telephony.TelephonyManager tm = (android.telephony.TelephonyManager) getSystemService(android.content.Context.TELEPHONY_SERVICE);
		android.net.wifi.WifiManager wm = (android.net.wifi.WifiManager) getApplicationContext().getSystemService(android.content.Context.WIFI_SERVICE);
		
		// ==========================================
		//           TELEPHONY (SIM & NETWORK)
		// ==========================================
		_item = new HashMap<>();
		_item.put("title", "Telephony"); 
		_item.put("info", ""); // হেডার বানানোর জন্য info ফাঁকা
		listmap.add(_item);
		
		try {
			String phoneType = "Unknown";
			switch (tm.getPhoneType()) {
				case 1: phoneType = "GSM"; break;
				case 2: phoneType = "CDMA"; break;
				case 3: phoneType = "SIP"; break;
				case 0: phoneType = "None"; break;
			}
			_item = new HashMap<>(); _item.put("title", "Phone Type"); _item.put("info", phoneType); listmap.add(_item);
			
			String netName = tm.getNetworkOperatorName();
			String netCountry = tm.getNetworkCountryIso();
			String simName = tm.getSimOperatorName();
			String simCountry = tm.getSimCountryIso();
			
			_item = new HashMap<>(); _item.put("title", "Network Operator Name"); _item.put("info", netName); listmap.add(_item);
			_item = new HashMap<>(); _item.put("title", "Network Operator Code"); _item.put("info", tm.getNetworkOperator()); listmap.add(_item);
			_item = new HashMap<>(); _item.put("title", "Network Operator Country"); _item.put("info", netCountry != null ? netCountry.toUpperCase() : ""); listmap.add(_item);
			_item = new HashMap<>(); _item.put("title", "SIM Provider Name"); _item.put("info", simName); listmap.add(_item);
			_item = new HashMap<>(); _item.put("title", "SIM Provider Code"); _item.put("info", tm.getSimOperator()); listmap.add(_item);
			_item = new HashMap<>(); _item.put("title", "SIM Provider Country"); _item.put("info", simCountry != null ? simCountry.toUpperCase() : ""); listmap.add(_item);
			
			String simState = "Unknown";
			switch (tm.getSimState()) {
				case 1: simState = "Absent"; break;
				case 5: simState = "Ready"; break;
				case 2: simState = "PIN Required"; break;
				case 3: simState = "PUK Required"; break;
				case 4: simState = "Network Locked"; break;
			}
			_item = new HashMap<>(); _item.put("title", "SIM State"); _item.put("info", simState); listmap.add(_item);
			
			_item = new HashMap<>(); _item.put("title", "Device Is Roaming"); _item.put("info", tm.isNetworkRoaming() ? "Yes" : "No"); listmap.add(_item);
			_item = new HashMap<>(); _item.put("title", "ICC Card"); _item.put("info", tm.hasIccCard() ? "Present" : "Absent"); listmap.add(_item);
		} catch (Exception e) {}
		
		// ==========================================
		//                  WI-FI
		// ==========================================
		_item = new HashMap<>();
		_item.put("title", "\nWi-Fi"); // নতুন লাইন দিয়ে স্পেস তৈরি
		_item.put("info", ""); // হেডার বানানোর জন্য info ফাঁকা
		listmap.add(_item);
		
		try {
			String wState = wm.isWifiEnabled() ? "Enabled" : "Disabled";
			_item = new HashMap<>(); _item.put("title", "State"); _item.put("info", wState); listmap.add(_item);
			
			if (wm.isWifiEnabled()) {
				android.net.wifi.WifiInfo wInfo = wm.getConnectionInfo();
				_item = new HashMap<>(); _item.put("title", "SSID"); _item.put("info", wInfo.getSSID()); listmap.add(_item);
				_item = new HashMap<>(); _item.put("title", "BSSID"); _item.put("info", wInfo.getBSSID()); listmap.add(_item);
				_item = new HashMap<>(); _item.put("title", "Hidden SSID"); _item.put("info", wInfo.getHiddenSSID() ? "Yes" : "No"); listmap.add(_item);
				
				int ip = wInfo.getIpAddress();
				String ipStr = String.format("%d.%d.%d.%d", (ip & 0xff), (ip >> 8 & 0xff), (ip >> 16 & 0xff), (ip >> 24 & 0xff));
				_item = new HashMap<>(); _item.put("title", "IPv4 Address"); _item.put("info", ipStr); listmap.add(_item);
				
				_item = new HashMap<>(); _item.put("title", "Signal Strength"); _item.put("info", wInfo.getRssi() + " dBm"); listmap.add(_item);
				_item = new HashMap<>(); _item.put("title", "Link Speed"); _item.put("info", wInfo.getLinkSpeed() + " Mbps"); listmap.add(_item);
				
				if (android.os.Build.VERSION.SDK_INT >= 21) {
					_item = new HashMap<>(); _item.put("title", "Frequency"); _item.put("info", wInfo.getFrequency() + " MHz"); listmap.add(_item);
				}
				
				android.net.DhcpInfo dhcp = wm.getDhcpInfo();
				if (dhcp != null) {
					int gw = dhcp.gateway;
					_item = new HashMap<>(); _item.put("title", "Gateway"); _item.put("info", String.format("%d.%d.%d.%d", (gw & 0xff), (gw >> 8 & 0xff), (gw >> 16 & 0xff), (gw >> 24 & 0xff))); listmap.add(_item);
					
					int nm = dhcp.netmask;
					_item = new HashMap<>(); _item.put("title", "Netmask"); _item.put("info", String.format("%d.%d.%d.%d", (nm & 0xff), (nm >> 8 & 0xff), (nm >> 16 & 0xff), (nm >> 24 & 0xff))); listmap.add(_item);
					
					int dns = dhcp.dns1;
					_item = new HashMap<>(); _item.put("title", "DNS1"); _item.put("info", String.format("%d.%d.%d.%d", (dns & 0xff), (dns >> 8 & 0xff), (dns >> 16 & 0xff), (dns >> 24 & 0xff))); listmap.add(_item);
				}
				
				if (android.os.Build.VERSION.SDK_INT >= 21) {
					_item = new HashMap<>(); _item.put("title", "5 GHz Band"); _item.put("info", wm.is5GHzBandSupported() ? "Supported" : "Not Supported"); listmap.add(_item);
					_item = new HashMap<>(); _item.put("title", "Wi-Fi Direct"); _item.put("info", wm.isP2pSupported() ? "Supported" : "Not Supported"); listmap.add(_item);
				}
			}
		} catch (Exception e) {}
		binding.listview1.setAdapter(new Listview1Adapter(listmap));
		((BaseAdapter)binding.listview1.getAdapter()).notifyDataSetChanged();
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			InfoRowBinding binding = InfoRowBinding.inflate(getLayoutInflater());
			View _view = binding.getRoot();
			
			binding.textview1.setText(listmap.get((int)_position).get("title").toString());
			binding.textview2.setText(listmap.get((int)_position).get("info").toString());
			if (listmap.get((int)_position).get("info").toString().equals("")) {
				binding.textview2.setVisibility(View.GONE);
				binding.textview1.setGravity(Gravity.CENTER_VERTICAL | Gravity.CENTER_HORIZONTAL);
				binding.textview1.setTypeface(Typeface.DEFAULT, 1);
			} else {
				binding.textview2.setVisibility(View.VISIBLE);
				binding.textview1.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
				binding.textview1.setTypeface(Typeface.DEFAULT, 0);
			}
			
			return _view;
		}
	}
}