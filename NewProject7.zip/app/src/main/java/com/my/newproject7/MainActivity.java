package com.my.newproject7;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ListView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.android.material.appbar.AppBarLayout;
import com.my.newproject7.databinding.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class MainActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private MainBinding binding;
	
	private ArrayList<HashMap<String, Object>> listmap = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> drawer_map = new ArrayList<>();
	
	private Intent intent = new Intent();
	private TimerTask timer;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		binding = MainBinding.inflate(getLayoutInflater());
		setContentView(binding.getRoot());
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		setSupportActionBar(binding.Toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		binding.Toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		
		binding.listview1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				if (_position == 0) {
					intent.setClass(getApplicationContext(), SystemActivity.class);
					startActivity(intent);
				}
				if (_position == 1) {
					intent.setClass(getApplicationContext(), CpuActivity.class);
					startActivity(intent);
				}
				if (_position == 2) {
					intent.setClass(getApplicationContext(), DisplayActivity.class);
					startActivity(intent);
				}
				if (_position == 3) {
					intent.setClass(getApplicationContext(), NetworkActivity.class);
					startActivity(intent);
				}
				if (_position == 4) {
					intent.setClass(getApplicationContext(), BatteryActivity.class);
					startActivity(intent);
				}
				if (_position == 5) {
					intent.setClass(getApplicationContext(), AndroidActivity.class);
					startActivity(intent);
				}
				if (_position == 6) {
					intent.setClass(getApplicationContext(), DeviceActivity.class);
					startActivity(intent);
				}
				if (_position == 7) {
					intent.setClass(getApplicationContext(), ThermalActivity.class);
					startActivity(intent);
				}
				if (_position == 8) {
					intent.setClass(getApplicationContext(), SensorsActivity.class);
					startActivity(intent);
				}
				if (_position == 9) {
					intent.setClass(getApplicationContext(), AppsActivity.class);
					startActivity(intent);
				}
				if (_position == 10) {
					intent.setClass(getApplicationContext(), CodecsActivity.class);
					startActivity(intent);
				}
				if (_position == 11) {
					intent.setClass(getApplicationContext(), DirectoriesActivity.class);
					startActivity(intent);
				}
				if (_position == 12) {
					intent.setClass(getApplicationContext(), SystemfilesActivity.class);
					startActivity(intent);
				}
				if (_position == 13) {
					intent.setClass(getApplicationContext(), AboutActivity.class);
					startActivity(intent);
				}
			}
		});
	}
	
	private void initializeLogic() {
		{
			HashMap<String, Object> _item = new HashMap<>();
			_item.put("title", "System");
			listmap.add(_item);
		}
		{
			HashMap<String, Object> _item = new HashMap<>();
			_item.put("title", "CPU");
			listmap.add(_item);
		}
		{
			HashMap<String, Object> _item = new HashMap<>();
			_item.put("title", "Display");
			listmap.add(_item);
		}
		{
			HashMap<String, Object> _item = new HashMap<>();
			_item.put("title", "Network");
			listmap.add(_item);
		}
		{
			HashMap<String, Object> _item = new HashMap<>();
			_item.put("title", "Battery");
			listmap.add(_item);
		}
		{
			HashMap<String, Object> _item = new HashMap<>();
			_item.put("title", "Android");
			listmap.add(_item);
		}
		{
			HashMap<String, Object> _item = new HashMap<>();
			_item.put("title", "Devices");
			listmap.add(_item);
		}
		{
			HashMap<String, Object> _item = new HashMap<>();
			_item.put("title", "Thermal");
			listmap.add(_item);
		}
		{
			HashMap<String, Object> _item = new HashMap<>();
			_item.put("title", "Sensors");
			listmap.add(_item);
		}
		{
			HashMap<String, Object> _item = new HashMap<>();
			_item.put("title", "Apps");
			listmap.add(_item);
		}
		{
			HashMap<String, Object> _item = new HashMap<>();
			_item.put("title", "Codecs");
			listmap.add(_item);
		}
		{
			HashMap<String, Object> _item = new HashMap<>();
			_item.put("title", "Directories");
			listmap.add(_item);
		}
		{
			HashMap<String, Object> _item = new HashMap<>();
			_item.put("title", "System Files");
			listmap.add(_item);
		}
		{
			HashMap<String, Object> _item = new HashMap<>();
			_item.put("title", "About");
			listmap.add(_item);
		}
		binding.listview1.setAdapter(new Listview1Adapter(listmap));
		((BaseAdapter)binding.listview1.getAdapter()).notifyDataSetChanged();
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			CustomRowBinding binding = CustomRowBinding.inflate(getLayoutInflater());
			View _view = binding.getRoot();
			
			binding.textview1.setText(listmap.get((int)_position).get("title").toString());
			
			return _view;
		}
	}
}